package com.mphai.Rectanglemodifier;

import java.util.Scanner;

public class RectangleAttribute {
	 int length; 
	    int width; 
	    int A; 
	    int P;
	    
	    public int getLength() {
			return length;
		}

		public void setLength(int length) {
			this.length = length;
		}

		public int getWidth() {
			return width;
		}

		public void setWidth(int width) {
			this.width = width;
		}

		
	    public RectangleAttribute()
	    {
	    	length = 1;
	    	width= 1;
	    }

	    void input() {
	        Scanner in = new Scanner(System.in);
	        System.out.print("Enter length of rectangle: ");
	        length = in.nextInt();
	        System.out.print("Enter width of rectangle: ");
	        width = in.nextInt();
	    }
	    
	    void  area()
	    {
	        A = length * width;
	       
	    }
	 
	     void  perimeter()
	    {
	    	 P = 2*(length + width);
	       
	    }

	    void display() {
	    	if(length>0 && length<20)
	        {
	        System.out.println("Area of Rectangle = " + A);
	        System.out.println("Parameter of Rectangle = " +P);}
	       
	        }

	    public static void main(String args[]) {
	    	
	    	RectangleAttribute obj1 = new RectangleAttribute();
	        obj1.input();
	        obj1.area();
	        obj1.perimeter();
	        obj1.display();
	        System.out.println("****************************");
	        RectangleAttribute obj2 = new RectangleAttribute();
	        obj2.input();
	        obj2.area();
	        obj2.perimeter();
	        obj2.display();
	        System.out.println("****************************");
	        RectangleAttribute obj3 = new RectangleAttribute();
	        obj3.input();
	        obj3.area();
	        obj3.perimeter();
	        obj3.display();
	        System.out.println("****************************");
	        RectangleAttribute obj4 = new RectangleAttribute();
	        obj4.input();
	        obj4.area();
	        obj4.perimeter();
	        obj4.display();
	        System.out.println("****************************");
	        RectangleAttribute obj5 = new RectangleAttribute();
	        obj5.input();
	        obj5.area();
	        obj5.perimeter();
	        obj5.display();
	    	
	    }

}
