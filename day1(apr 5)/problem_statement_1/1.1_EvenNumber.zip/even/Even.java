package com.mphasis.even;
import java.util.Scanner;
public class Even {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first number");
		int a=sc.nextInt();
		System.out.print("enter second number");
		int b=sc.nextInt();
		int i;
		for(i=a;i<=b;i++) {
			if(i%2==0)
			{
				System.out.println(i);
			}
		}
	}

}
