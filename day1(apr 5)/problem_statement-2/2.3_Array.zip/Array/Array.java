package com.mphasis.Array;

public class Array {
	 
	    public static void main(String[] args) {  
	        //Initialize array  
	        int [] arr = new int [] {1,2,3,4,5};  
	        int sum = 0,temp,avg = 0;  
	        //Loop through the array to calculate sum of elements  
	        for (int i = 0; i < arr.length; i++) {  
	           sum = sum + arr[i];
	           //average 
	           avg=sum/arr.length;
	           
	           //smallest finding
	           for(int j=i+1;j<arr.length;j++) {
	        	   if(arr[i]>arr[j]) {
	        		   temp=arr[i];
	        		   arr[i]=arr[j];
	        		   arr[j]=temp;
	        		   
	        	   }
	        		   
	        
	           }
	        }  
	        System.out.println("Sum of all the elements of an array: " + sum);  
	        System.out.println("smallest element: " + arr[0]); 
	        System.out.println("avarage is :"+avg);
	        
	    }  
	}  


