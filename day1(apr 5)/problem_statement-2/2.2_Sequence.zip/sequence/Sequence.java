package com.mphasis.sequence;
import java.util.Scanner;
public class Sequence {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first number");
		int n1=sc.nextInt();
		System.out.println("Enter Second number");
		int n2=sc.nextInt();
		System.out.println("Enter range ");
		int r=sc.nextInt();
		for(int i=1;i<=r;i++)
		{
			 System.out.print(n1 + " ");

		      int n = n1 + n2;
		      n1 = n2;
		      n2 = n;
		}
	}

}
